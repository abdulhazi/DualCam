package com.stevensenjaya.dualcam;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.graphics.Color;
import android.graphics.SurfaceTexture;
import android.graphics.Typeface;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.TotalCaptureResult;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Surface;
import android.view.TextureView;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Collections;
import java.util.Set;

/**
 * Ignores what the phone *says* and simply tries it: opens the back camera, then the front
 * camera while the back one is still running, and counts frames from both for a few seconds.
 * If both keep delivering frames, real dual recording is possible on this phone.
 * (The previews here may look rotated or stretched; only the frame counts matter.)
 */
@SuppressLint({"MissingPermission", "SetTextI18n"})
public class DualTestActivity extends Activity {

    private TextureView backView, frontView;
    private TextView logText, fpsText, verdictText;
    private CameraManager mgr;
    private HandlerThread thread;
    private Handler bg;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private CameraDevice backDev, frontDev;
    private CameraCaptureSession backSes, frontSes;
    private volatile int backFrames, frontFrames;
    private int lastBack, lastFront, bothOkSeconds, secondsSinceFront = -1;
    private boolean started, done, frontRequested;
    private String backId, frontId;
    private final StringBuilder log = new StringBuilder();

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            int b = backFrames - lastBack, f = frontFrames - lastFront;
            lastBack = backFrames;
            lastFront = frontFrames;
            fpsText.setText("Back: " + b + " fps    Front: " + f + " fps");
            if (secondsSinceFront >= 0) secondsSinceFront++;
            if (!done) {
                if (b > 0 && f > 0) bothOkSeconds++;
                else bothOkSeconds = 0;
                if (bothOkSeconds >= 3) {
                    verdict(true, "YES – both cameras stream at the same time.\n"
                            + "Real dual recording should be possible on this phone.");
                } else if (secondsSinceFront >= 8) {
                    verdict(false, "NO – the phone won't run both cameras together for apps.\n"
                            + (f == 0 && b > 0 ? "The front camera never delivered frames."
                            : b == 0 && f > 0 ? "The back camera stopped when the front one started."
                            : "Neither kept running."));
                }
            }
            ui.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        mgr = (CameraManager) getSystemService(CAMERA_SERVICE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.BLACK);
        root.setPadding(dp(12), dp(28), dp(12), dp(12));

        TextView title = text(18, Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setText("Dual camera test");
        root.addView(title);

        verdictText = text(15, 0xFFFFD166);
        verdictText.setTypeface(Typeface.DEFAULT_BOLD);
        verdictText.setText("Testing... hold still for about 10 seconds");
        verdictText.setPadding(0, dp(6), 0, dp(6));
        root.addView(verdictText);

        fpsText = text(14, Color.WHITE);
        fpsText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        root.addView(fpsText);

        LinearLayout views = new LinearLayout(this);
        views.setOrientation(LinearLayout.HORIZONTAL);
        backView = new TextureView(this);
        frontView = new TextureView(this);
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        vp.setMargins(dp(4), dp(8), dp(4), dp(8));
        views.addView(backView, vp);
        LinearLayout.LayoutParams vp2 = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        vp2.setMargins(dp(4), dp(8), dp(4), dp(8));
        views.addView(frontView, vp2);
        root.addView(views, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        logText = text(12, 0xCCFFFFFF);
        logText.setTypeface(Typeface.MONOSPACE);
        logText.setTextIsSelectable(true);
        root.addView(logText, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 0.9f));

        setContentView(root);

        TextureView.SurfaceTextureListener l = new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture s, int w, int h) { maybeStart(); }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture s, int w, int h) { }
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture s) { return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture s) { }
        };
        backView.setSurfaceTextureListener(l);
        frontView.setSurfaceTextureListener(l);
    }

    @Override
    protected void onResume() {
        super.onResume();
        thread = new HandlerThread("dualtest");
        thread.start();
        bg = new Handler(thread.getLooper());
        ui.postDelayed(ticker, 1000);
        maybeStart();
    }

    @Override
    protected void onPause() {
        super.onPause();
        ui.removeCallbacksAndMessages(null);
        closeAll();
        if (thread != null) thread.quitSafely();
        finish();   // one-shot screen; reopen it to test again
    }

    private void maybeStart() {
        if (started || bg == null || !backView.isAvailable() || !frontView.isAvailable()) return;
        started = true;
        // Give the main screen a moment to release its camera.
        ui.postDelayed(this::startTest, 800);
    }

    private void startTest() {
        try {
            add("Phone: " + android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL);
            for (String id : mgr.getCameraIdList()) {
                Integer f = mgr.getCameraCharacteristics(id).get(CameraCharacteristics.LENS_FACING);
                if (f == null) continue;
                if (f == CameraCharacteristics.LENS_FACING_BACK && backId == null) backId = id;
                if (f == CameraCharacteristics.LENS_FACING_FRONT && frontId == null) frontId = id;
            }
            Set<Set<String>> pairs = mgr.getConcurrentCameraIds();
            add("Camera IDs: back " + backId + ", front " + frontId);
            add("Pairs the phone officially allows together: " + pairs.size() + " " + pairs);
        } catch (Exception e) {
            add("Couldn't read cameras: " + e.getMessage());
        }
        if (backId == null || frontId == null) {
            verdict(false, "Couldn't find both a back and a front camera.");
            return;
        }
        add("Opening back camera...");
        open(backId, true);
    }

    private void open(String id, boolean isBack) {
        String name = isBack ? "Back" : "Front";
        try {
            mgr.openCamera(id, new CameraDevice.StateCallback() {
                @Override
                public void onOpened(CameraDevice d) {
                    if (isBack) backDev = d; else frontDev = d;
                    add(name + " camera opened");
                    startPreview(d, isBack);
                }

                @Override
                public void onDisconnected(CameraDevice d) {
                    add(name + " camera was taken away (disconnected)");
                    d.close();
                    if (isBack) backDev = null; else frontDev = null;
                }

                @Override
                public void onError(CameraDevice d, int error) {
                    add(name + " camera error " + error + " (" + errName(error) + ")");
                    d.close();
                    if (isBack) backDev = null; else frontDev = null;
                    if (!isBack) secondsSinceFront = Math.max(secondsSinceFront, 0);
                }
            }, bg);
        } catch (CameraAccessException | SecurityException e) {
            add(name + " open failed: " + e.getMessage());
            if (!isBack) secondsSinceFront = 0;
        }
    }

    @SuppressWarnings("deprecation")
    private void startPreview(CameraDevice d, boolean isBack) {
        try {
            TextureView tv = isBack ? backView : frontView;
            SurfaceTexture st = tv.getSurfaceTexture();
            if (st == null) { add("Preview surface missing"); return; }
            st.setDefaultBufferSize(1280, 720);
            Surface s = new Surface(st);
            CaptureRequest.Builder rb = d.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW);
            rb.addTarget(s);
            d.createCaptureSession(Collections.singletonList(s), new CameraCaptureSession.StateCallback() {
                @Override
                public void onConfigured(CameraCaptureSession ses) {
                    if (isBack) backSes = ses; else frontSes = ses;
                    try {
                        ses.setRepeatingRequest(rb.build(), new CameraCaptureSession.CaptureCallback() {
                            @Override
                            public void onCaptureCompleted(CameraCaptureSession session, CaptureRequest request,
                                                           TotalCaptureResult result) {
                                if (isBack) backFrames++; else frontFrames++;
                            }
                        }, bg);
                        add((isBack ? "Back" : "Front") + " camera streaming");
                    } catch (Exception e) {
                        add("Start stream failed: " + e.getMessage());
                    }
                    if (isBack) requestFront();
                }

                @Override
                public void onConfigureFailed(CameraCaptureSession ses) {
                    add((isBack ? "Back" : "Front") + " session could not be configured");
                    if (isBack) requestFront();
                }
            }, bg);
        } catch (Exception e) {
            add("Preview failed: " + e.getMessage());
            if (isBack) requestFront();
        }
    }

    private void requestFront() {
        if (frontRequested) return;
        frontRequested = true;
        ui.postDelayed(() -> {
            add("Opening front camera while back is running...");
            secondsSinceFront = 0;
            open(frontId, false);
        }, 1500);
    }

    private void verdict(boolean ok, String msg) {
        if (done) return;
        done = true;
        verdictText.setTextColor(ok ? 0xFF7CFC8A : 0xFFFF6B6B);
        verdictText.setText(msg);
        add("RESULT: " + (ok ? "dual works" : "dual not possible"));
    }

    private void closeAll() {
        try { if (backSes != null) backSes.close(); } catch (Exception ignored) { }
        try { if (frontSes != null) frontSes.close(); } catch (Exception ignored) { }
        try { if (backDev != null) backDev.close(); } catch (Exception ignored) { }
        try { if (frontDev != null) frontDev.close(); } catch (Exception ignored) { }
        backSes = frontSes = null;
        backDev = frontDev = null;
    }

    private static String errName(int e) {
        switch (e) {
            case CameraDevice.StateCallback.ERROR_CAMERA_IN_USE: return "camera in use";
            case CameraDevice.StateCallback.ERROR_MAX_CAMERAS_IN_USE: return "too many cameras open";
            case CameraDevice.StateCallback.ERROR_CAMERA_DISABLED: return "camera disabled";
            case CameraDevice.StateCallback.ERROR_CAMERA_DEVICE: return "camera device error";
            case CameraDevice.StateCallback.ERROR_CAMERA_SERVICE: return "camera service error";
            default: return "unknown";
        }
    }

    private void add(String line) {
        ui.post(() -> {
            log.append(line).append('\n');
            logText.setText(log.toString());
        });
    }

    private TextView text(int sp, int color) {
        TextView t = new TextView(this);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        return t;
    }

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }
}
