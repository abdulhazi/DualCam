package com.stevensenjaya.dualcam;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.Range;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.OrientationEventListener;
import android.view.Surface;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import androidx.camera.camera2.interop.Camera2CameraInfo;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraInfo;
import androidx.camera.core.DynamicRange;
import androidx.camera.core.ResolutionInfo;
import androidx.camera.core.resolutionselector.AspectRatioStrategy;
import androidx.camera.core.resolutionselector.ResolutionSelector;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.CompositionSettings;
import androidx.camera.core.ConcurrentCamera;
import androidx.camera.core.MirrorMode;
import androidx.camera.core.Preview;
import androidx.camera.core.UseCaseGroup;
import androidx.camera.core.ZoomState;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.video.FallbackStrategy;
import androidx.camera.video.MediaStoreOutputOptions;
import androidx.camera.video.PendingRecording;
import androidx.camera.video.Quality;
import androidx.camera.video.QualitySelector;
import androidx.camera.video.Recorder;
import androidx.camera.video.Recording;
import androidx.camera.video.VideoCapture;
import androidx.camera.video.VideoRecordEvent;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;

import com.google.common.util.concurrent.ListenableFuture;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * DualCam: video recording with
 *  - SINGLE mode: one camera at a time, and the front/back flip works WHILE recording
 *    (the clip keeps going into the same file), plus lens buttons (0.6x / 1x / 2x / 5x).
 *  - DUAL mode: front and back cameras at the same time, saved as one picture-in-picture
 *    video. The swap button changes which camera is big, also while recording.
 * Dual mode only appears if the phone lets apps open both cameras at once; the
 * "i" button shows exactly what the phone reports.
 * Stabilization is left on wherever the phone supports it.
 */
@SuppressLint({"UnsafeOptInUsageError", "MissingPermission", "SetTextI18n", "SourceLockedOrientationActivity"})
public class MainActivity extends ComponentActivity {

    private static final int REQ_PERMS = 41;
    private static final int RED = 0xFFE5383B;
    private static final int ACCENT = 0xFFFFD166;

    /** One lens button: which physical camera to open and which zoom to set on it. */
    private static final class LensOption {
        CameraInfo info;
        String cameraId;
        float zoom;     // zoom ratio to set on that camera
        float ratio;    // what the button shows, relative to the main back lens
        String label;
    }

    // ---- camera objects ----
    private ProcessCameraProvider provider;
    private CameraInfo backInfo, frontInfo;            // defaults for single mode
    private CameraInfo dualBackInfo, dualFrontInfo;    // the pair that can run together
    private boolean concurrentFeature, dualSupported;
    private boolean videoStabAll;                       // every single-mode camera can stabilize video
    private final List<LensOption> backOptions = new ArrayList<>();
    private final List<CameraInfo> allCameras = new ArrayList<>();
    private String lastBindNote = "";
    private Quality singleQuality = Quality.HD;        // a quality every single-mode camera supports
    private String singleQualityName = "720p";
    private boolean fps30All;                          // every single-mode camera can do a steady 30 fps
    private boolean captureStab;                       // video stabilization on the current recording setup
    private boolean previewStabNow;                    // preview stabilization on the current camera
    private String streamNote = "";

    private Camera camera;                     // bound camera in single mode
    private ConcurrentCamera concurrentCamera; // bound pair in dual mode
    private VideoCapture<Recorder> singleCapture;
    private VideoCapture<Recorder> dualCapture;
    private Preview dualPreview;
    private Recording recording;
    private int targetRotation = Surface.ROTATION_0;

    // ---- state ----
    private boolean dualMode = false;
    private boolean useFront = false;      // single mode: front camera active
    private boolean frontIsMain = false;   // dual mode: front camera is the big one
    private LensOption backOption;         // chosen back lens (single mode)
    private float dualZoom = 1f;
    private boolean busy = false;          // short guard against double taps while switching

    // ---- views ----
    private PreviewView previewView;
    private TextView modeBtn, infoBtn, timerText, statusText;
    private LinearLayout lensRow;
    private FrameLayout recordBtn;
    private View recordInner;
    private FrameLayout flipBtn;
    private TextView flipLabel;
    private OrientationEventListener orientationListener;
    private final Handler ui = new Handler(Looper.getMainLooper());

    // =====================================================================================
    // Lifecycle
    // =====================================================================================

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildUi();

        orientationListener = new OrientationEventListener(this) {
            @Override
            public void onOrientationChanged(int deg) {
                if (deg == ORIENTATION_UNKNOWN) return;
                int r;
                if (deg >= 45 && deg < 135) r = Surface.ROTATION_270;
                else if (deg >= 135 && deg < 225) r = Surface.ROTATION_180;
                else if (deg >= 225 && deg < 315) r = Surface.ROTATION_90;
                else r = Surface.ROTATION_0;
                if (r == targetRotation) return;
                targetRotation = r;
                // The rotation is fixed when a recording starts, so only update when idle.
                if (recording == null) applyRotation();
            }
        };

        if (hasPerm(Manifest.permission.CAMERA)) {
            startCamera();
        } else {
            requestPermissions(new String[]{Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO}, REQ_PERMS);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (orientationListener != null && orientationListener.canDetectOrientation()) {
            orientationListener.enable();
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (orientationListener != null) orientationListener.disable();
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        // Coming back from the dual test screen (which released the cameras).
        if (provider != null && recording == null) bindCurrent();
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Recordings are "persistent" (so they survive a camera switch), which also means
        // they would keep running in the background. Stop them when the app is left.
        stopRecording();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode != REQ_PERMS) return;
        if (hasPerm(Manifest.permission.CAMERA)) {
            startCamera();
        } else {
            statusText.setText("Camera permission is needed. Allow it in Settings > Apps > DualCam.");
        }
    }

    private boolean hasPerm(String p) {
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED;
    }

    // =====================================================================================
    // Camera setup
    // =====================================================================================

    private void startCamera() {
        final ListenableFuture<ProcessCameraProvider> future = ProcessCameraProvider.getInstance(this);
        future.addListener(() -> {
            try {
                provider = future.get();
            } catch (Exception e) {
                statusText.setText("Camera could not start: " + e.getMessage());
                return;
            }
            probeCameras();
            bindCurrent();
        }, ContextCompat.getMainExecutor(this));
    }

    /** Looks at what the phone exposes: lenses, zoom ranges, and front+back support. */
    private void probeCameras() {
        allCameras.clear();
        try {
            allCameras.addAll(provider.getAvailableCameraInfos());
        } catch (Exception ignored) {
        }
        backInfo = infoFor(CameraSelector.DEFAULT_BACK_CAMERA);
        frontInfo = infoFor(CameraSelector.DEFAULT_FRONT_CAMERA);

        // ---- front + back at the same time? ----
        concurrentFeature = getPackageManager()
                .hasSystemFeature(PackageManager.FEATURE_CAMERA_CONCURRENT);
        dualSupported = false;
        dualBackInfo = null;
        dualFrontInfo = null;
        try {
            for (List<CameraInfo> pair : provider.getAvailableConcurrentCameraInfos()) {
                CameraInfo b = null, f = null;
                for (CameraInfo ci : pair) {
                    if (ci.getLensFacing() == CameraSelector.LENS_FACING_BACK && b == null) b = ci;
                    if (ci.getLensFacing() == CameraSelector.LENS_FACING_FRONT && f == null) f = ci;
                }
                if (b != null && f != null) {
                    dualBackInfo = b;
                    dualFrontInfo = f;
                    dualSupported = true;
                    break;
                }
            }
        } catch (Exception ignored) {
        }

        // ---- back lens buttons ----
        backOptions.clear();
        if (backInfo != null) {
            Range<Float> zr = zoomRange(backInfo);
            float lo = zr.getLower(), hi = zr.getUpper();
            String backId = idOf(backInfo);
            if (lo < 0.95f) addOption(backInfo, backId, lo, lo);
            addOption(backInfo, backId, 1f, 1f);
            if (hi >= 2f) addOption(backInfo, backId, 2f, 2f);
            if (hi >= 5f) addOption(backInfo, backId, 5f, 5f);

            // Lenses the main camera can't reach by zooming (often the ultrawide on Xiaomi)
            // are offered as their own camera.
            float base = backInfo.getIntrinsicZoomRatio();
            for (CameraInfo ci : allCameras) {
                if (ci.getLensFacing() != CameraSelector.LENS_FACING_BACK) continue;
                String id = idOf(ci);
                if (id.equals(backId)) continue;
                float rel = base > 0 ? ci.getIntrinsicZoomRatio() / base : 1f;
                if (rel >= lo - 0.05f && rel <= hi + 0.05f) continue;
                boolean dup = false;
                for (LensOption o : backOptions) {
                    if (Math.abs(o.ratio - rel) < 0.08f) { dup = true; break; }
                }
                if (!dup) addOption(ci, id, 1f, rel);
            }
            Collections.sort(backOptions, (a, b) -> Float.compare(a.ratio, b.ratio));
            for (LensOption o : backOptions) {
                if (o.cameraId.equals(backId) && o.zoom == 1f) backOption = o;
            }
        }

        // ---- stabilization ----
        // Video stabilization can only be set once per recording, so it is switched on only
        // if every camera single mode can switch to supports it. Preview stabilization is
        // set per camera on top of that (it stabilizes the recording too).
        List<CameraInfo> singleCams = new ArrayList<>();
        if (frontInfo != null) singleCams.add(frontInfo);
        for (LensOption o : backOptions) singleCams.add(o.info);
        videoStabAll = !singleCams.isEmpty();
        for (CameraInfo ci : singleCams) {
            if (!videoStabSupported(ci)) { videoStabAll = false; break; }
        }

        // ---- one resolution every camera can deliver, so switching never stretches ----
        Quality[] candidates = {Quality.FHD, Quality.HD, Quality.SD};
        String[] names = {"1080p", "720p", "480p"};
        singleQuality = Quality.HD;
        singleQualityName = "720p";
        for (int i = 0; i < candidates.length; i++) {
            boolean all = !singleCams.isEmpty();
            for (CameraInfo ci : singleCams) {
                if (!qualitySupported(ci, candidates[i])) { all = false; break; }
            }
            if (all) {
                singleQuality = candidates[i];
                singleQualityName = names[i];
                break;
            }
        }

        // ---- steady 30 fps (otherwise indoors the camera may drop to 15-20 fps) ----
        Range<Integer> fixed30 = new Range<>(30, 30);
        fps30All = !singleCams.isEmpty();
        for (CameraInfo ci : singleCams) {
            boolean has = false;
            try {
                has = ci.getSupportedFrameRateRanges().contains(fixed30);
            } catch (Exception ignored) {
            }
            if (!has) { fps30All = false; break; }
        }

        updateStatus();
    }

    private static boolean qualitySupported(CameraInfo info, Quality q) {
        try {
            return Recorder.getVideoCapabilities(info).isQualitySupported(q, DynamicRange.SDR);
        } catch (Exception e) {
            return false;
        }
    }

    private void updateStatus() {
        String dual = dualSupported
                ? "Dual camera: supported on this phone"
                : "Dual camera: phone says no (tap SINGLE to run a test)";
        String stab = (captureStab || previewStabNow) ? "stabilization ON" : "stabilization OFF";
        String line2 = dualMode ? "Dual: 720p"
                : (streamNote.isEmpty() ? singleQualityName : streamNote)
                + (fps30All ? " · 30fps" : "") + " · " + stab;
        statusText.setText(dual + "\n" + line2);
    }

    private void addOption(CameraInfo info, String id, float zoom, float ratio) {
        LensOption o = new LensOption();
        o.info = info;
        o.cameraId = id;
        o.zoom = zoom;
        o.ratio = ratio;
        o.label = zoomLabel(ratio);
        backOptions.add(o);
    }

    private CameraInfo infoFor(CameraSelector selector) {
        try {
            return provider.getCameraInfo(selector);
        } catch (Exception e) {
            return null;
        }
    }

    private static String idOf(CameraInfo info) {
        try {
            return Camera2CameraInfo.from(info).getCameraId();
        } catch (Exception e) {
            return "?";
        }
    }

    private static Range<Float> zoomRange(CameraInfo info) {
        try {
            Range<Float> r = Camera2CameraInfo.from(info)
                    .getCameraCharacteristic(CameraCharacteristics.CONTROL_ZOOM_RATIO_RANGE);
            if (r != null) return r;
        } catch (Exception ignored) {
        }
        ZoomState zs = info.getZoomState().getValue();
        if (zs != null) return new Range<>(zs.getMinZoomRatio(), zs.getMaxZoomRatio());
        return new Range<>(1f, 1f);
    }

    private static boolean previewStabSupported(CameraInfo info) {
        try {
            return Preview.getPreviewCapabilities(info).isStabilizationSupported();
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean videoStabSupported(CameraInfo info) {
        try {
            return Recorder.getVideoCapabilities(info).isStabilizationSupported();
        } catch (Exception e) {
            return false;
        }
    }

    // =====================================================================================
    // Binding
    // =====================================================================================

    private void bindCurrent() {
        if (provider == null) return;
        if (dualMode && dualSupported) bindDual();
        else bindSingle();
        refreshControls();
        updateStatus();
    }

    private static ResolutionSelector ratio169() {
        return new ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy.RATIO_16_9_FALLBACK_AUTO_STRATEGY)
                .build();
    }

    private VideoCapture<Recorder> newCapture(QualitySelector qs, boolean stabilize,
                                              boolean mirrorFront, boolean fps30) {
        Recorder recorder = new Recorder.Builder()
                .setQualitySelector(qs)
                // Same 16:9 shape on every camera, so a mid-recording switch isn't stretched.
                .setAspectRatio(AspectRatio.RATIO_16_9)
                .build();
        VideoCapture.Builder<Recorder> b = new VideoCapture.Builder<>(recorder);
        if (mirrorFront) b.setMirrorMode(MirrorMode.MIRROR_MODE_ON_FRONT_ONLY);
        if (stabilize) b.setVideoStabilizationEnabled(true);
        if (fps30) b.setTargetFrameRate(new Range<>(30, 30));
        VideoCapture<Recorder> vc = b.build();
        vc.setTargetRotation(targetRotation);
        return vc;
    }

    private CameraInfo currentSingleInfo() {
        return useFront ? frontInfo : (backOption != null ? backOption.info : backInfo);
    }

    /**
     * One camera. While recording, the same VideoCapture is reused so the clip carries on.
     * When idle it is rebuilt, so stabilization matches the camera in use (and the one a flip
     * would switch to). Returns false if the camera couldn't be opened.
     */
    private boolean bindSingle() {
        CameraInfo info = currentSingleInfo();
        if (info == null) {
            toast(useFront ? "No front camera found" : "No back camera found");
            return false;
        }
        if (recording == null || singleCapture == null) {
            CameraInfo other = useFront ? (backOption != null ? backOption.info : backInfo) : frontInfo;
            boolean stab = videoStabSupported(info) && (other == null || videoStabSupported(other));
            captureStab = stab;
            // Exact quality (no fallback) so every camera delivers the same size.
            singleCapture = newCapture(QualitySelector.from(singleQuality), stab, true, fps30All);
        }
        previewStabNow = previewStabSupported(info);
        Preview.Builder pb = new Preview.Builder().setResolutionSelector(ratio169());
        if (previewStabNow) pb.setPreviewStabilizationEnabled(true);
        Preview preview = pb.build();
        preview.setSurfaceProvider(previewView.getSurfaceProvider());

        boolean ok;
        try {
            provider.unbindAll();
            concurrentCamera = null;
            camera = provider.bindToLifecycle(this, info.getCameraSelector(), preview, singleCapture);
            if (!useFront && backOption != null && backOption.zoom != 1f) {
                camera.getCameraControl().setZoomRatio(backOption.zoom);
            }
            ResolutionInfo ri = singleCapture.getResolutionInfo();
            streamNote = ri != null
                    ? ri.getResolution().getWidth() + "x" + ri.getResolution().getHeight()
                    : singleQualityName;
            lastBindNote = "Single: camera " + idOf(info)
                    + (useFront ? " (front)" : " (back)") + ", " + streamNote
                    + ", video stab " + (captureStab ? "on" : "off")
                    + ", preview stab " + (previewStabNow ? "on" : "off");
            ok = true;
        } catch (Exception e) {
            camera = null;
            lastBindNote = "Single bind failed: " + e.getMessage();
            toast("Couldn't open that camera: " + e.getMessage());
            ok = false;
        }
        updateStatus();
        return ok;
    }

    /** Front + back together, composed by CameraX into one picture-in-picture stream. */
    private void bindDual() {
        if (dualCapture == null) {
            // Dual camera is limited to 720p on most phones.
            dualCapture = newCapture(QualitySelector.fromOrderedList(
                    Arrays.asList(Quality.HD, Quality.SD),
                    FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)), false, false, false);
        }
        if (dualPreview == null) {
            dualPreview = new Preview.Builder().build();
            dualPreview.setSurfaceProvider(previewView.getSurfaceProvider());
        }
        UseCaseGroup group = new UseCaseGroup.Builder()
                .addUseCase(dualPreview)
                .addUseCase(dualCapture)
                .build();

        CameraInfo main = frontIsMain ? dualFrontInfo : dualBackInfo;
        CameraInfo small = frontIsMain ? dualBackInfo : dualFrontInfo;

        CompositionSettings big = new CompositionSettings.Builder()
                .setAlpha(1f)
                .setOffset(0f, 0f)
                .setScale(1f, 1f)
                .build();
        // Small window in the corner, a third of the frame.
        CompositionSettings pip = new CompositionSettings.Builder()
                .setAlpha(1f)
                .setOffset(2f / 3f - 0.1f, -2f / 3f + 0.1f)
                .setScale(1f / 3f, 1f / 3f)
                .build();

        try {
            provider.unbindAll();
            camera = null;
            List<ConcurrentCamera.SingleCameraConfig> configs = new ArrayList<>();
            configs.add(new ConcurrentCamera.SingleCameraConfig(main.getCameraSelector(), group, big, this));
            configs.add(new ConcurrentCamera.SingleCameraConfig(small.getCameraSelector(), group, pip, this));
            concurrentCamera = provider.bindToLifecycle(configs);
            if (dualZoom != 1f) {
                Camera back = dualBackCamera();
                if (back != null) back.getCameraControl().setZoomRatio(dualZoom);
            }
            lastBindNote = "Dual: big = camera " + idOf(main) + ", small = camera " + idOf(small);
        } catch (Exception e) {
            concurrentCamera = null;
            lastBindNote = "Dual bind failed: " + e.getMessage();
            toast("Dual camera failed: " + e.getMessage());
            if (recording == null) {
                // Fall back to single mode so the app stays usable.
                dualMode = false;
                bindSingle();
            }
        }
    }

    private Camera dualBackCamera() {
        if (concurrentCamera == null) return null;
        for (Camera c : concurrentCamera.getCameras()) {
            if (c.getCameraInfo().getLensFacing() == CameraSelector.LENS_FACING_BACK) return c;
        }
        return null;
    }

    private void applyRotation() {
        if (singleCapture != null) singleCapture.setTargetRotation(targetRotation);
        if (dualCapture != null) dualCapture.setTargetRotation(targetRotation);
    }

    // =====================================================================================
    // Actions
    // =====================================================================================

    private void onFlip() {
        if (provider == null || busy) return;
        holdBusy();
        if (dualMode) {
            frontIsMain = !frontIsMain;
            bindDual();
        } else {
            if (frontInfo == null && !useFront) {
                toast("No front camera found");
                return;
            }
            useFront = !useFront;
            if (!bindSingle()) {          // switch refused: go back to the camera we had
                useFront = !useFront;
                bindSingle();
            }
        }
        refreshControls();
    }

    private void onModeToggle() {
        if (provider == null || busy) return;
        if (recording != null) {
            toast("Stop recording to change mode");
            return;
        }
        if (!dualSupported) {
            new AlertDialog.Builder(this)
                    .setTitle("Dual camera")
                    .setMessage("Your phone reports that apps can't use the front and back cameras "
                            + "at the same time.\n\nRun a test that tries anyway? It opens both "
                            + "cameras and checks whether they really stream together.")
                    .setPositiveButton("Run test", (d, w) -> launchDualTest())
                    .setNegativeButton("Cancel", null)
                    .show();
            return;
        }
        holdBusy();
        dualMode = !dualMode;
        bindCurrent();
    }

    private void onLens(LensOption o) {
        if (busy) return;
        LensOption prev = backOption;
        backOption = o;
        if (camera != null && prev != null && prev.cameraId.equals(o.cameraId)) {
            camera.getCameraControl().setZoomRatio(o.zoom);   // same lens: smooth zoom
        } else {
            holdBusy();
            if (!bindSingle()) {                                // other lens: reopen
                backOption = prev;                              // refused: back to previous lens
                bindSingle();
            }
        }
        refreshControls();
    }

    private void launchDualTest() {
        if (recording != null) {
            toast("Stop recording first");
            return;
        }
        if (provider != null) provider.unbindAll();   // free both cameras for the test
        camera = null;
        concurrentCamera = null;
        startActivity(new Intent(this, DualTestActivity.class));
    }

    private void onDualZoom(float z) {
        dualZoom = z;
        Camera back = dualBackCamera();
        if (back != null) back.getCameraControl().setZoomRatio(z);
        refreshControls();
    }

    private void holdBusy() {
        busy = true;
        ui.postDelayed(() -> busy = false, 700);
    }

    private void onRecordTap() {
        if (recording != null) stopRecording();
        else startRecording();
    }

    private void startRecording() {
        VideoCapture<Recorder> vc = dualMode ? dualCapture : singleCapture;
        if (vc == null || (dualMode ? concurrentCamera == null : camera == null)) {
            toast("Camera isn't ready");
            return;
        }
        String name = "DualCam_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        ContentValues cv = new ContentValues();
        cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
        cv.put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4");
        cv.put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/DualCam");
        MediaStoreOutputOptions out = new MediaStoreOutputOptions.Builder(
                getContentResolver(), MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
                .setContentValues(cv)
                .build();

        try {
            // Persistent = keeps recording into the same file when the camera is switched.
            PendingRecording pending = vc.getOutput().prepareRecording(this, out).asPersistentRecording();
            if (hasPerm(Manifest.permission.RECORD_AUDIO)) pending = pending.withAudioEnabled();
            recording = pending.start(ContextCompat.getMainExecutor(this), this::onRecordEvent);
        } catch (Exception e) {
            recording = null;
            toast("Couldn't start recording: " + e.getMessage());
        }
        refreshControls();
    }

    private void stopRecording() {
        if (recording != null) {
            recording.stop();
            recording = null;
        }
        refreshControls();
    }

    private void onRecordEvent(VideoRecordEvent e) {
        if (e instanceof VideoRecordEvent.Status) {
            long s = e.getRecordingStats().getRecordedDurationNanos() / 1_000_000_000L;
            timerText.setText(String.format(Locale.US, "● %02d:%02d", s / 60, s % 60));
        } else if (e instanceof VideoRecordEvent.Finalize) {
            VideoRecordEvent.Finalize f = (VideoRecordEvent.Finalize) e;
            Uri uri = f.getOutputResults().getOutputUri();
            boolean saved = uri != null && !Uri.EMPTY.equals(uri);
            if (saved) {
                toast(f.hasError()
                        ? "Saved to DCIM/DualCam (ended early, code " + f.getError() + ")"
                        : "Saved to DCIM/DualCam");
            } else {
                toast("Recording failed (code " + f.getError() + ")");
            }
            recording = null;
            applyRotation();
            refreshControls();
        }
    }

    // =====================================================================================
    // UI
    // =====================================================================================

    private int dp(float v) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v,
                getResources().getDisplayMetrics()));
    }

    private static GradientDrawable pill(int fill, int stroke, int strokeW, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(radius);
        if (strokeW > 0) g.setStroke(strokeW, stroke);
        return g;
    }

    private TextView chip(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(Color.WHITE);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(14), 0, dp(14), 0);
        t.setBackground(pill(0x66000000, 0, 0, dp(18)));
        return t;
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);

        previewView = new PreviewView(this);
        previewView.setScaleType(PreviewView.ScaleType.FIT_CENTER);   // show the full recorded frame
        root.addView(previewView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // ---------------- top ----------------
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.VERTICAL);
        top.setPadding(dp(16), dp(28), dp(16), 0);

        FrameLayout topRow = new FrameLayout(this);
        modeBtn = chip("SINGLE");
        modeBtn.setOnClickListener(v -> onModeToggle());
        topRow.addView(modeBtn, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(36), Gravity.START | Gravity.CENTER_VERTICAL));

        timerText = new TextView(this);
        timerText.setTextColor(Color.WHITE);
        timerText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16);
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timerText.setGravity(Gravity.CENTER);
        timerText.setPadding(dp(12), dp(4), dp(12), dp(4));
        timerText.setBackground(pill(RED, 0, 0, dp(6)));
        timerText.setVisibility(View.GONE);
        topRow.addView(timerText, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        infoBtn = chip("i");
        infoBtn.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC));
        infoBtn.setPadding(0, 0, 0, 0);
        infoBtn.setOnClickListener(v -> showInfo());
        topRow.addView(infoBtn, new FrameLayout.LayoutParams(dp(36), dp(36),
                Gravity.END | Gravity.CENTER_VERTICAL));
        top.addView(topRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(40)));

        statusText = new TextView(this);
        statusText.setTextColor(0xCCFFFFFF);
        statusText.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        statusText.setPadding(0, dp(6), 0, 0);
        statusText.setText("Starting camera...");
        top.addView(statusText);

        root.addView(top, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));

        // ---------------- bottom ----------------
        LinearLayout bottom = new LinearLayout(this);
        bottom.setOrientation(LinearLayout.VERTICAL);
        bottom.setGravity(Gravity.CENTER_HORIZONTAL);
        bottom.setPadding(0, 0, 0, dp(36));

        lensRow = new LinearLayout(this);
        lensRow.setOrientation(LinearLayout.HORIZONTAL);
        lensRow.setGravity(Gravity.CENTER);
        lensRow.setPadding(dp(4), dp(4), dp(4), dp(4));
        lensRow.setBackground(pill(0x55000000, 0, 0, dp(24)));
        LinearLayout.LayoutParams lrp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(48));
        lrp.bottomMargin = dp(20);
        bottom.addView(lensRow, lrp);

        FrameLayout controls = new FrameLayout(this);

        recordBtn = new FrameLayout(this);
        recordBtn.setBackground(pill(Color.TRANSPARENT, Color.WHITE, dp(4), dp(40)));
        recordInner = new View(this);
        recordBtn.addView(recordInner, new FrameLayout.LayoutParams(dp(60), dp(60), Gravity.CENTER));
        recordBtn.setOnClickListener(v -> onRecordTap());
        controls.addView(recordBtn, new FrameLayout.LayoutParams(dp(80), dp(80), Gravity.CENTER));

        flipBtn = new FrameLayout(this);
        flipBtn.setBackground(pill(0x66000000, 0, 0, dp(28)));
        ImageView flipIcon = new ImageView(this);
        flipIcon.setImageResource(R.drawable.ic_flip);
        flipBtn.addView(flipIcon, new FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER));
        flipBtn.setOnClickListener(v -> onFlip());
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(dp(56), dp(56),
                Gravity.CENTER_VERTICAL | Gravity.END);
        fp.rightMargin = dp(36);
        controls.addView(flipBtn, fp);

        flipLabel = new TextView(this);
        flipLabel.setTextColor(0xCCFFFFFF);
        flipLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        flipLabel.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams flp = new FrameLayout.LayoutParams(dp(80),
                ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.END);
        flp.rightMargin = dp(24);
        controls.addView(flipLabel, flp);

        bottom.addView(controls, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(100)));

        root.addView(bottom, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));

        setContentView(root);
        refreshControls();
    }

    private void refreshControls() {
        boolean rec = recording != null;

        // record button: red circle -> red rounded square while recording
        recordInner.setBackground(pill(RED, 0, 0, rec ? dp(8) : dp(30)));
        FrameLayout.LayoutParams ip = (FrameLayout.LayoutParams) recordInner.getLayoutParams();
        ip.width = ip.height = rec ? dp(34) : dp(60);
        recordInner.setLayoutParams(ip);

        timerText.setVisibility(rec ? View.VISIBLE : View.GONE);
        if (!rec) timerText.setText("● 00:00");

        modeBtn.setText(dualMode ? "DUAL" : "SINGLE");
        modeBtn.setTextColor(dualMode ? ACCENT : Color.WHITE);
        modeBtn.setAlpha(rec || !dualSupported ? 0.45f : 1f);

        flipLabel.setText(dualMode ? "swap" : (useFront ? "front" : "back"));

        // lens / zoom buttons
        lensRow.removeAllViews();
        if (dualMode) {
            Camera back = dualBackCamera();
            Range<Float> zr = back != null ? zoomRange(back.getCameraInfo()) : new Range<>(1f, 1f);
            List<Float> steps = new ArrayList<>();
            if (zr.getLower() < 0.95f) steps.add(zr.getLower());
            steps.add(1f);
            if (zr.getUpper() >= 2f) steps.add(2f);
            if (steps.size() > 1) {
                for (final float z : steps) {
                    addLensChip(zoomLabel(z), Math.abs(z - dualZoom) < 0.01f, v -> onDualZoom(z));
                }
            }
        } else if (!useFront && backOptions.size() > 1) {
            for (final LensOption o : backOptions) {
                addLensChip(o.label, o == backOption, v -> onLens(o));
            }
        }
        lensRow.setVisibility(lensRow.getChildCount() > 0 ? View.VISIBLE : View.INVISIBLE);
    }

    private void addLensChip(String label, boolean selected, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(label);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, selected ? 13 : 12);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextColor(selected ? ACCENT : Color.WHITE);
        t.setBackground(pill(selected ? 0x99000000 : 0x00000000, 0, 0, dp(20)));
        t.setOnClickListener(l);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(dp(44), dp(40));
        p.leftMargin = p.rightMargin = dp(2);
        lensRow.addView(t, p);
    }

    private static String zoomLabel(float r) {
        if (Math.abs(r - Math.round(r)) < 0.05f && r >= 0.95f) return Math.round(r) + "x";
        return String.format(Locale.US, "%.1fx", r);
    }

    /** Everything the phone reports, so it's clear why a feature is or isn't available. */
    private void showInfo() {
        StringBuilder sb = new StringBuilder();
        sb.append("Phone: ").append(Build.MANUFACTURER).append(' ').append(Build.MODEL)
                .append(", Android ").append(Build.VERSION.RELEASE).append("\n\n");
        sb.append("Front+back at once (system flag): ").append(concurrentFeature ? "YES" : "NO").append('\n');
        if (provider != null) {
            try {
                List<List<CameraInfo>> pairs = provider.getAvailableConcurrentCameraInfos();
                sb.append("Camera pairs that can run together: ").append(pairs.size()).append('\n');
                for (List<CameraInfo> pair : pairs) {
                    sb.append("  [");
                    for (int i = 0; i < pair.size(); i++) {
                        if (i > 0) sb.append(" + ");
                        sb.append(idOf(pair.get(i))).append(' ').append(facing(pair.get(i)));
                    }
                    sb.append("]\n");
                }
            } catch (Exception e) {
                sb.append("Camera pairs: error ").append(e.getMessage()).append('\n');
            }
        }
        sb.append("Dual mode: ").append(dualSupported ? "available" : "not available").append("\n\n");

        sb.append("Cameras apps can open:\n");
        for (CameraInfo ci : allCameras) {
            Range<Float> zr = zoomRange(ci);
            sb.append("  id ").append(idOf(ci)).append("  ").append(facing(ci))
                    .append(String.format(Locale.US, "  fov x%.2f  zoom %.2f-%.1f",
                            ci.getIntrinsicZoomRatio(), zr.getLower(), zr.getUpper()))
                    .append("\n     stab: preview ").append(previewStabSupported(ci) ? "yes" : "no")
                    .append(", video ").append(videoStabSupported(ci) ? "yes" : "no").append('\n');
        }
        sb.append("\nBack lens buttons:\n");
        for (LensOption o : backOptions) {
            sb.append("  ").append(o.label).append(" = camera ").append(o.cameraId)
                    .append(String.format(Locale.US, " at zoom %.2f", o.zoom)).append('\n');
        }
        sb.append("\nVideo stab supported on every camera: ").append(videoStabAll ? "yes" : "no").append('\n');
        sb.append("Recording size used on all cameras: ").append(singleQualityName)
                .append(fps30All ? ", fixed 30 fps" : ", fps not fixed").append('\n');
        sb.append("Now: ").append(lastBindNote).append('\n');

        TextView tv = new TextView(this);
        tv.setText(sb.toString());
        tv.setTextIsSelectable(true);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12);
        tv.setPadding(dp(20), dp(12), dp(20), dp(12));
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this)
                .setTitle("Camera info")
                .setView(sv)
                .setPositiveButton("OK", null)
                .setNeutralButton("Dual test", (d, w) -> launchDualTest())
                .show();
    }

    private static String facing(CameraInfo ci) {
        int f = ci.getLensFacing();
        return f == CameraSelector.LENS_FACING_BACK ? "back"
                : f == CameraSelector.LENS_FACING_FRONT ? "front" : "other";
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
