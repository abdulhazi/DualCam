# DualCam

Video camera for the Xiaomi 15T Pro (works on other Android 11+ phones too).

- **SINGLE mode**: one camera; tap the flip button while recording to switch front/back
  without stopping. The clip continues in the same file. Lens buttons (0.6x / 1x / 2x / 5x)
  also work while recording.
- **DUAL mode**: front and back cameras together, saved as one picture-in-picture video
  (720p). The swap button changes which camera is big, also while recording.
  Only shown as available if the phone lets apps open both cameras at once.
- **i** button: shows what the phone reports (camera list, dual support, stabilization).
- Stabilization stays on wherever the phone supports it.
- Videos save to `DCIM/DualCam`.

Build: push the project zip with `.github/workflows/build.yml` at the repo root; the APK appears
under Releases.
